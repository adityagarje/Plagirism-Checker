#!/usr/bin/env python
# coding: utf-8

# In[1]:


from difflib import SequenceMatcher


# In[11]:


# file handling 
with open('demo1.txt') as one_file, open('demo2.txt') as two_file:
    data_file1 = one_file.read()
    data_file2 = two_file.read()
    matches = SequenceMatcher(None, data_file1, data_file2).ratio()
    print(f"The plagirized content is {matches}%")


# In[ ]:




